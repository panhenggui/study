set NAMES utf8;
set @dt =NOW();
select distinct exchange_id,product_id,instrument_id from t_code_map; 
