set NAMES utf8;
set @dt =NOW();
select distinct  ex_exchange_id,ex_product_id,exchange_id,product_id,instrument_id from t_code_map where (IF((delivery_year = (select year(@dt))),(delivery_month <= IF((( select month(@dt)) + 14 ) >= 12 ,12,(select month(@dt))+14)),IF((delivery_year = ((select year(@dt))+1)),delivery_month <= IF((( select month(@dt)) + 2  ) <= 0 ,( select month(@dt)),(select month(@dt))+2),delivery_month < 0))
and ( exchange_id="NYMEX" or exchange_id="BMD" or exchange_id="CBOT" or exchange_id="CME" or exchange_id="COMEX" or exchange_id="EUREX" or exchange_id="HKFE" or exchange_id="ICEU" or exchange_id="LIFFE" or exchange_id="SGX" or exchange_id="TOCOM" ) or exchange_id="LME" ) and code_type=1 LIMIT 250,50


