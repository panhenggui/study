set NAMES utf8;
set @dt =NOW();
select exchangeid,productid,instrumentid from t_oper_instrument where exchangeid="CFFEX" or exchangeid="SHFE" or exchangeid="DCE" or exchangeid="CZCE" or exchangeid="INE" or exchangeid="SGE" or exchangeid="BXG" or exchangeid="SSE" or exchangeid="SZSE";

